import styled from "styled-components";

const Footer = () =>{
    return(
        <Foot>

        </Foot>
    )
}

export default Footer;

const Foot = styled.div`
/* margin-top: 40px; */
height: 10vh;
background-color: #35363a;
`